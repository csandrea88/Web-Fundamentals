$(document).ready(function(){ 
     
     $('img').click(function(){
        $(this).css ("opacity","0");
    });

});